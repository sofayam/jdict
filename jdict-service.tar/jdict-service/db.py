"""
db.py — Database access layer for jdict-service.
"""

import json
import sqlite3
from pathlib import Path
from typing import Optional

DB_PATH = Path("data/jdict.db")


def get_conn() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA query_only=ON")
    return conn


# ── Shared connection (FastAPI is single-process; use thread-safe WAL mode) ──
_conn: Optional[sqlite3.Connection] = None


def conn() -> sqlite3.Connection:
    global _conn
    if _conn is None:
        _conn = get_conn()
    return _conn


def db_exists() -> bool:
    return DB_PATH.exists()


# ─────────────────────────────────────────────
# Result shaping
# ─────────────────────────────────────────────

def _row_to_entry(row) -> dict:
    return {
        "seq":    row["seq"],
        "kanji":  json.loads(row["kanji_json"]  or "[]"),
        "kana":   json.loads(row["kana_json"]   or "[]"),
        "senses": json.loads(row["senses_json"] or "[]"),
        "jlpt":   row["jlpt"],
    }


# ─────────────────────────────────────────────
# Search
# ─────────────────────────────────────────────

def search(q: str, lang: str = "eng", limit: int = 20, offset: int = 0) -> list[dict]:
    """
    Search by kanji, kana, or gloss.
    Uses FTS5 for full-text search; falls back to LIKE for exact prefix on
    Japanese text (FTS5 doesn't tokenise CJK characters well by default).
    """
    q = q.strip()
    if not q:
        return []

    c = conn()

    # Detect if query contains Japanese characters (CJK Unified, Hiragana, Katakana)
    is_japanese = any('\u3000' <= ch or '\u3040' <= ch <= '\u30ff' or '\u4e00' <= ch <= '\u9fff'
                      for ch in q)

    if is_japanese:
        # LIKE search against kanji/kana columns for CJK
        rows = c.execute("""
            SELECT e.seq, e.kanji_json, e.kana_json, e.senses_json, e.jlpt
            FROM entries e
            JOIN entries_fts f ON f.seq = e.seq
            WHERE f.kanji LIKE ? OR f.kana LIKE ?
            LIMIT ? OFFSET ?
        """, (f"%{q}%", f"%{q}%", limit, offset)).fetchall()
    else:
        # FTS5 for romaji / English gloss
        # Append * for prefix matching on the last token
        fts_query = " ".join(word + "*" for word in q.split())
        try:
            rows = c.execute("""
                SELECT e.seq, e.kanji_json, e.kana_json, e.senses_json, e.jlpt
                FROM entries e
                JOIN entries_fts f ON f.seq = e.seq
                WHERE entries_fts MATCH ?
                ORDER BY rank
                LIMIT ? OFFSET ?
            """, (fts_query, limit, offset)).fetchall()
        except sqlite3.OperationalError:
            # Fallback for malformed FTS queries
            rows = c.execute("""
                SELECT e.seq, e.kanji_json, e.kana_json, e.senses_json, e.jlpt
                FROM entries e
                JOIN entries_fts f ON f.seq = e.seq
                WHERE f.glosses LIKE ?
                LIMIT ? OFFSET ?
            """, (f"%{q}%", limit, offset)).fetchall()

    return [_row_to_entry(r) for r in rows]


def get_entry(seq: int) -> Optional[dict]:
    """Look up a single entry by JMdict sequence number."""
    row = conn().execute(
        "SELECT seq, kanji_json, kana_json, senses_json, jlpt FROM entries WHERE seq=?",
        (seq,)
    ).fetchone()
    return _row_to_entry(row) if row else None


def get_by_jlpt(level: str, limit: int = 50, offset: int = 0) -> list[dict]:
    """Return entries tagged with a given JLPT level (N1–N5)."""
    rows = conn().execute(
        "SELECT seq, kanji_json, kana_json, senses_json, jlpt FROM entries WHERE jlpt=? LIMIT ? OFFSET ?",
        (level.upper(), limit, offset)
    ).fetchall()
    return [_row_to_entry(r) for r in rows]


def random_entries(n: int = 5) -> list[dict]:
    """Return n random entries (useful for 'word of the day' etc.)."""
    rows = conn().execute(
        "SELECT seq, kanji_json, kana_json, senses_json, jlpt FROM entries ORDER BY RANDOM() LIMIT ?",
        (n,)
    ).fetchall()
    return [_row_to_entry(r) for r in rows]


def entry_count() -> int:
    row = conn().execute("SELECT COUNT(*) as c FROM entries").fetchone()
    return row["c"] if row else 0
